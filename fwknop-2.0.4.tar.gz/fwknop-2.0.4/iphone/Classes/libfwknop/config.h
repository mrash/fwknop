/*
 *  config.h
 *  Fwknop
 *
 *  Created by Dev on 9/16/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

/* MACOSX: Need to set these for MACOSX*/	
#define HAVE_SYS_TIME_H 1
#define IPHONE 1


